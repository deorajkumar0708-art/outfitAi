import os, itertools, json
from flask import Flask, render_template, request, jsonify

app = Flask(__name__)

COLORS = ["black","white","blue","navy","grey","gray","beige","brown","green","red","pink","yellow","cream","denim"]
TOPS = ["t-shirt","shirt","top","polo","sweater","hoodie","kurta","blouse"]
BOTTOMS = ["jeans","trousers","pants","shorts","skirt","chinos","pajama"]
SHOES = ["sneakers","shoes","boots","sandals","loafers","heels"]

def classify(name):
    n = name.lower()
    if any(x in n for x in TOPS): return "top"
    if any(x in n for x in BOTTOMS): return "bottom"
    if any(x in n for x in SHOES): return "shoes"
    return "other"

def demo_outfits(items, occasion="casual", weather="warm", style="smart casual"):
    groups = {"top":[], "bottom":[], "shoes":[], "other":[]}
    for x in items:
        groups.setdefault(x.get("category") or classify(x.get("name","")), []).append(x)
    outfits=[]
    for t,b,s in itertools.product(groups["top"], groups["bottom"], groups["shoes"]):
        text=f'{t["name"]} + {b["name"]} + {s["name"]}'
        score=80
        if "formal" in occasion.lower() and any(k in t["name"].lower() for k in ["t-shirt","hoodie"]): score-=12
        if "rain" in weather.lower() and any(k in s["name"].lower() for k in ["sandals"]): score-=10
        if "smart" in style.lower() and any(k in s["name"].lower() for k in ["sneakers"]): score+=3
        outfits.append({"items":[t,b,s],"score":max(50,min(98,score)), "reason":f"Balanced for {occasion}, {weather} weather and {style} style."})
    return sorted(outfits,key=lambda x:-x["score"])[:8]

@app.route("/")
def home():
    return render_template("index.html")

@app.get("/api/plans")
def plans():
    return jsonify([
        {"id":"weekly","name":"Weekly","price_inr":29,"period":"week","description":"Try Pro with a low-risk weekly plan."},
        {"id":"monthly","name":"Monthly","price_inr":79,"period":"month","description":"Best balance for regular users.","badge":"POPULAR"},
        {"id":"yearly","name":"Yearly","price_inr":699,"period":"year","description":"Best value for long-term users.","badge":"BEST VALUE"}
    ])

@app.post("/api/create-order")
def create_order():
    data=request.get_json(force=True)
    plan=data.get("plan","monthly")
    prices={"weekly":29,"monthly":79,"yearly":699}
    if plan not in prices:
        return jsonify({"error":"Invalid plan"}),400
    # Demo order response. Connect Razorpay Orders API server-side for production.
    return jsonify({"plan":plan,"amount_inr":prices[plan],"currency":"INR","status":"ready_for_razorpay"})

@app.post("/api/outfits")
def outfits():
    data=request.get_json(force=True)
    return jsonify(demo_outfits(data.get("items",[]),data.get("occasion","casual"),data.get("weather","warm"),data.get("style","smart casual")))

@app.post("/api/analyze")
def analyze():
    # Safe demo analyzer. Replace with a vision provider in production.
    name=(request.get_json(force=True).get("name") or "New clothing item").strip()
    return jsonify({"name":name, "category":classify(name), "message":"Item added. For automatic photo recognition, connect your preferred vision API in the server."})

if __name__=="__main__":
    app.run(host="0.0.0.0", port=int(os.getenv("PORT","5000")), debug=True)
