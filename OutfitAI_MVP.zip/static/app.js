const key="outfitai_items";
let items=JSON.parse(localStorage.getItem(key)||"[]");
const emojis={top:"👕",bottom:"👖",shoes:"👟",other:"🧥"};

function persist(){localStorage.setItem(key,JSON.stringify(items));renderCloset()}
function renderCloset(){
 const g=document.getElementById("closetGrid"), empty=document.getElementById("empty");
 empty.style.display=items.length?"none":"block";
 g.innerHTML=items.map((x,i)=>`<div class="item"><div class="emoji">${x.emoji||emojis[x.category]||"🧥"}</div><div><b>${escapeHtml(x.name)}</b><br><small>${x.category}</small></div><button onclick="removeItem(${i})" style="align-self:flex-end;background:#f2f1ed;padding:7px 10px">Remove</button></div>`).join("");
}
function addItem(){document.getElementById("modal").classList.remove("hidden");document.getElementById("itemName").focus()}
function closeModal(){document.getElementById("modal").classList.add("hidden")}
async function saveItem(){
 const name=document.getElementById("itemName").value.trim(); if(!name)return;
 const r=await fetch("/api/analyze",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({name})});
 const x=await r.json(); items.push({name:x.name,category:x.category,emoji:emojis[x.category]||"🧥"});persist();document.getElementById("itemName").value="";closeModal();showToast("Added to your closet")
}
function removeItem(i){items.splice(i,1);persist()}
async function generate(){
 if(!items.some(x=>x.category==="top")||!items.some(x=>x.category==="bottom")||!items.some(x=>x.category==="shoes")){showToast("Add a top, bottom and shoes first.");return}
 const payload={items,occasion:document.getElementById("occasion").value,weather:document.getElementById("weather").value,style:document.getElementById("style").value};
 const r=await fetch("/api/outfits",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(payload)});
 const data=await r.json(); const el=document.getElementById("results");
 el.innerHTML=data.map((o,i)=>`<div class="result"><div class="score">${o.score}%</div><div class="pieces">${o.items.map(x=>x.emoji||"🧥").join(" ")}</div><b>${o.items.map(x=>escapeHtml(x.name)).join(" · ")}</b><p>${o.reason}</p><button class="save" onclick='saveOutfit(${JSON.stringify(o).replaceAll("'","&#39;")})'>♡ Save outfit</button></div>`).join("");
}
function saveOutfit(o){let saved=JSON.parse(localStorage.getItem("outfitai_saved")||"[]");saved.push(o);localStorage.setItem("outfitai_saved",JSON.stringify(saved));renderSaved();showToast("Outfit saved")}
function renderSaved(){let s=JSON.parse(localStorage.getItem("outfitai_saved")||"[]");document.getElementById("savedGrid").innerHTML=s.slice().reverse().map(o=>`<div class="saved-card"><div class="pieces">${o.items.map(x=>x.emoji||"🧥").join(" ")}</div><b>${o.items.map(x=>escapeHtml(x.name)).join(" · ")}</b><p>${o.score}% match</p></div>`).join("")||'<p style="color:#777">Your saved outfits will appear here.</p>'}
function showToast(t){let x=document.getElementById("toast");x.textContent=t;x.style.display="block";clearTimeout(window.tt);window.tt=setTimeout(()=>x.style.display="none",2200)}
function escapeHtml(s){return s.replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[m]))}
renderCloset();renderSaved();
