# OutfitAI MVP

A responsive web MVP for an AI wardrobe/stylist product.

## Included
- Digital closet stored in the browser
- Clothing categorization
- Occasion/weather/style controls
- Outfit generation from the user's own wardrobe
- Outfit scoring
- Saved outfits
- Mobile responsive design
- Backend API ready for a real vision/LLM provider

## Run locally

1. Install Python 3.10+
2. `pip install -r requirements.txt`
3. `python app.py`
4. Open `http://localhost:5000`

## Production upgrades
1. Add photo upload + vision API for automatic clothing recognition.
2. Add accounts/database (PostgreSQL/Supabase).
3. Add Razorpay subscriptions.
4. Add weather API.
5. Add analytics and referral system.
6. Add affiliate product catalog.
7. Deploy to Render/Railway/Fly.io or another Python host.

## Important
Do not put secret API keys in frontend JavaScript. Keep them in server-side environment variables.
