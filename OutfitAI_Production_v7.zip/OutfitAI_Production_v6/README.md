# OutfitAI Production v6

AI personal stylist with cloud accounts, private wardrobe storage, OpenAI vision/styling, Razorpay subscriptions, weather, saved outfits, affiliate framework, and admin metrics.

## What's improved in v6
- Supabase Auth + Postgres + private Storage.
- Server-side authentication on protected Flask routes.
- Subscription records are tied to the signed-in user.
- Pro status is checked server-side instead of trusting a browser localStorage flag.
- Razorpay subscription creation stores the Supabase user ID in Razorpay notes and webhook processing preserves that ownership.
- Private clothing images use short-lived signed URLs; the database stores the storage path so URLs can be refreshed.
- OpenAI vision/stylist integration remains server-side.

## Environment variables
Copy `.env.example` to `.env` locally or configure these in your hosting provider. Never commit secrets.

Required for cloud login/data:
- `SUPABASE_URL`
- `SUPABASE_ANON_KEY`
- `SUPABASE_SERVICE_ROLE_KEY`

Required for AI:
- `OPENAI_API_KEY`
- `OPENAI_MODEL` (default: `gpt-5.6-luna`)

Required for Razorpay subscriptions:
- `RAZORPAY_KEY_ID`
- `RAZORPAY_KEY_SECRET`
- `RAZORPAY_PLAN_WEEKLY_ID`
- `RAZORPAY_PLAN_MONTHLY_ID`
- `RAZORPAY_PLAN_YEARLY_ID`
- `RAZORPAY_WEBHOOK_SECRET`

Optional:
- `WEATHERAPI_KEY`
- `AFFILIATE_BASE_URL`
- `ADMIN_EMAILS`

## Supabase setup
1. Create a Supabase project.
2. Open SQL Editor.
3. Run `supabase_schema.sql`.
4. In Authentication, configure email confirmation/redirect URLs as desired.
5. The SQL creates a private `closet-images` storage bucket and owner-only storage policies.

## Your Supabase project
- Region: `ap-south-1` (Mumbai)
- Project URL: `https://xlirpnjapobqzhvnyomi.supabase.co`
- Set the publishable/anon key in your hosting environment as `SUPABASE_ANON_KEY`.
- Set the Supabase server-side secret as `SUPABASE_SERVICE_ROLE_KEY` in the hosting environment only; never put it in frontend code or Git.

## Local run
```bash
python -m venv .venv
# Windows: .venv\\Scripts\\activate
# macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
python app.py
```

## Razorpay
Use Test Mode first. Create the three subscription plans, set their plan IDs in environment variables, and configure the webhook endpoint as:
`https://YOUR-DOMAIN/api/razorpay/webhook`

Recommended subscription webhook events include authentication, activation, charge, pause/resume, cancellation, and completion events. Keep the webhook secret private.

## Security
- Do not put `SUPABASE_SERVICE_ROLE_KEY`, `RAZORPAY_KEY_SECRET`, `RAZORPAY_WEBHOOK_SECRET`, or `OPENAI_API_KEY` in frontend code.
- Do not paste secrets into chat.
- Use HTTPS in production.
- Test Razorpay in Test Mode before Live Mode.
