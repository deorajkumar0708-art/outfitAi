# OutfitAI — Production Build v5

OutfitAI is an AI personal stylist / digital closet web app with Indian-first INR subscriptions.

## Included in v5
- AI clothing recognition through OpenAI Responses API
- AI outfit generation and AI stylist chat
- Digital closet
- Optional Supabase authentication, Postgres cloud sync and private photo storage
- Live weather integration through WeatherAPI.com
- Razorpay subscriptions: ₹29/week, ₹79/month, ₹699/year
- Razorpay subscription verification + webhook handling
- Optional affiliate shopping hook: **Complete My Outfit**
- Admin summary endpoint
- Responsive frontend
- Local fallback mode when cloud/AI/payment services are not configured

## Important setup
1. Create a Supabase project and run `supabase_schema.sql` in its SQL editor.
2. Copy `.env.example` to `.env` on your server and fill the values.
3. Keep `SUPABASE_SERVICE_ROLE_KEY`, `OPENAI_API_KEY`, `RAZORPAY_KEY_SECRET`, and `RAZORPAY_WEBHOOK_SECRET` server-side only.
4. Configure Razorpay webhook at your public HTTPS URL: `/api/razorpay/webhook`. Razorpay recommends public HTTPS webhooks and server-side signature validation. See official docs: https://razorpay.com/docs/webhooks/
5. For weather, create a WeatherAPI.com key and set `WEATHERAPI_KEY`. The free plan supports commercial use but requires attribution/link-back; add the attribution in the production UI before launch. See https://www.weatherapi.com/pricing.aspx and https://www.weatherapi.com/docs/
6. Set `AFFILIATE_BASE_URL` only after joining an affiliate program and use the destination format allowed by that network.
7. Set `ADMIN_EMAILS` to the email address(es) that may use `/api/admin/summary`.

## Supabase frontend settings
`SUPABASE_URL` and `SUPABASE_ANON_KEY` are returned by `/api/config` to the browser. The service-role key is never returned.

## Local run
```bash
python -m venv .venv
# Windows: .venv\\Scripts\\activate
# macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
python app.py
```

## Production notes
- Use a production WSGI server such as Gunicorn or another platform-native server.
- Set `debug=False` in production.
- Use HTTPS.
- Configure a custom domain when ready.
- Add a privacy policy and terms before collecting user photos/payments.
- Add image-size/type limits and rate limiting before public launch.
- Test Razorpay in Test Mode first. Razorpay documents subscription creation as Plan → Subscription → Checkout, with webhooks for asynchronous status updates.

## Architecture
Browser → Flask → OpenAI / Supabase / Razorpay / WeatherAPI / affiliate destination.

LocalStorage remains a fallback, so the demo works even before cloud services are configured.
