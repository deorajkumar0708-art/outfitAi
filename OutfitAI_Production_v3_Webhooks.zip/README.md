# OutfitAI MVP

A responsive web MVP for an AI wardrobe/stylist product.

## Included
- Digital closet stored in the browser
- Clothing categorization
- Occasion/weather/style controls
- Outfit generation from the user's own wardrobe
- Outfit scoring
- Saved outfits
- Mobile responsive design
- Backend API ready for a real vision/LLM provider

## Run locally

1. Install Python 3.10+
2. `pip install -r requirements.txt`
3. `python app.py`
4. Open `http://localhost:5000`

## Production upgrades
1. Add photo upload + vision API for automatic clothing recognition.
2. Add accounts/database (PostgreSQL/Supabase).
3. Add Razorpay subscriptions.
4. Add weather API.
5. Add analytics and referral system.
6. Add affiliate product catalog.
7. Deploy to Render/Railway/Fly.io or another Python host.

## Important
Do not put secret API keys in frontend JavaScript. Keep them in server-side environment variables.


## Subscription pricing added
- Weekly: ₹29/week
- Monthly: ₹79/month (POPULAR)
- Yearly: ₹699/year (BEST VALUE)

The UI includes a plan selector and checkout-ready API endpoint. For live payments, connect Razorpay Orders/Subscriptions server-side using environment variables. Never expose the Razorpay secret key in frontend code.


## Live Razorpay integration
The app now contains the server-side Razorpay Subscription API flow and signature verification.

### Razorpay setup
Create three Plans in the Razorpay Dashboard:
- Weekly: ₹29, weekly
- Monthly: ₹79, monthly
- Yearly: ₹699, yearly

Razorpay supports weekly/monthly/yearly subscription frequencies. Paste the resulting `plan_...` IDs into the three environment variables in `.env`.

Then set:
- `RAZORPAY_KEY_ID`
- `RAZORPAY_KEY_SECRET`
- `RAZORPAY_PLAN_WEEKLY_ID`
- `RAZORPAY_PLAN_MONTHLY_ID`
- `RAZORPAY_PLAN_YEARLY_ID`

Never put `RAZORPAY_KEY_SECRET` in frontend code or commit it to GitHub.

For a production launch, also add webhook handling so the database reflects subscription states even when a customer renews, cancels, or a payment fails.

## Subscription status + webhook layer
The app now stores Razorpay subscription status locally in SQLite and exposes:

`POST /api/razorpay/webhook`

Set `RAZORPAY_WEBHOOK_SECRET` in the server environment and configure the same secret in the Razorpay Dashboard. Recommended subscription events include `subscription.authenticated`, `subscription.activated`, `subscription.charged`, `subscription.completed`, `subscription.halted`, `subscription.cancelled`, `subscription.paused`, and `subscription.resumed`.

Razorpay sends subscription events asynchronously through webhooks, so this endpoint is intended to keep the app's subscription state synchronized. The webhook endpoint should be deployed on a public HTTPS URL before adding it in the Razorpay Dashboard.
