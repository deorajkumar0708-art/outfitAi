import os, itertools, json, hmac, hashlib
from flask import Flask, render_template, request, jsonify
try:
    import razorpay
except ImportError:
    razorpay = None

app = Flask(__name__)
RAZORPAY_KEY_ID = os.getenv("RAZORPAY_KEY_ID", "")
RAZORPAY_KEY_SECRET = os.getenv("RAZORPAY_KEY_SECRET", "")
RAZORPAY_PLAN_IDS = {
    "weekly": os.getenv("RAZORPAY_PLAN_WEEKLY_ID", ""),
    "monthly": os.getenv("RAZORPAY_PLAN_MONTHLY_ID", ""),
    "yearly": os.getenv("RAZORPAY_PLAN_YEARLY_ID", ""),
}
rzp = razorpay.Client(auth=(RAZORPAY_KEY_ID, RAZORPAY_KEY_SECRET)) if razorpay and RAZORPAY_KEY_ID and RAZORPAY_KEY_SECRET else None

COLORS = ["black","white","blue","navy","grey","gray","beige","brown","green","red","pink","yellow","cream","denim"]
TOPS = ["t-shirt","shirt","top","polo","sweater","hoodie","kurta","blouse"]
BOTTOMS = ["jeans","trousers","pants","shorts","skirt","chinos","pajama"]
SHOES = ["sneakers","shoes","boots","sandals","loafers","heels"]

def classify(name):
    n = name.lower()
    if any(x in n for x in TOPS): return "top"
    if any(x in n for x in BOTTOMS): return "bottom"
    if any(x in n for x in SHOES): return "shoes"
    return "other"

def demo_outfits(items, occasion="casual", weather="warm", style="smart casual"):
    groups = {"top":[], "bottom":[], "shoes":[], "other":[]}
    for x in items:
        groups.setdefault(x.get("category") or classify(x.get("name","")), []).append(x)
    outfits=[]
    for t,b,s in itertools.product(groups["top"], groups["bottom"], groups["shoes"]):
        text=f'{t["name"]} + {b["name"]} + {s["name"]}'
        score=80
        if "formal" in occasion.lower() and any(k in t["name"].lower() for k in ["t-shirt","hoodie"]): score-=12
        if "rain" in weather.lower() and any(k in s["name"].lower() for k in ["sandals"]): score-=10
        if "smart" in style.lower() and any(k in s["name"].lower() for k in ["sneakers"]): score+=3
        outfits.append({"items":[t,b,s],"score":max(50,min(98,score)), "reason":f"Balanced for {occasion}, {weather} weather and {style} style."})
    return sorted(outfits,key=lambda x:-x["score"])[:8]

@app.route("/")
def home():
    return render_template("index.html")

@app.get("/api/plans")
def plans():
    return jsonify([
        {"id":"weekly","name":"Weekly","price_inr":29,"period":"week","description":"Try Pro with a low-risk weekly plan."},
        {"id":"monthly","name":"Monthly","price_inr":79,"period":"month","description":"Best balance for regular users.","badge":"POPULAR"},
        {"id":"yearly","name":"Yearly","price_inr":699,"period":"year","description":"Best value for long-term users.","badge":"BEST VALUE"}
    ])

@app.post("/api/create-subscription")
def create_subscription():
    data=request.get_json(force=True)
    plan=data.get("plan","monthly")
    prices={"weekly":29,"monthly":79,"yearly":699}
    if plan not in prices:
        return jsonify({"error":"Invalid plan"}),400
    plan_id=RAZORPAY_PLAN_IDS.get(plan,"")
    if not rzp or not plan_id:
        return jsonify({
            "configured":False,
            "plan":plan,
            "amount_inr":prices[plan],
            "message":"Razorpay is not configured yet. Add the server environment variables and Razorpay plan IDs."
        }), 200
    try:
        # Long-running subscription; customer can cancel through your account flow.
        sub=rzp.subscription.create({
            "plan_id": plan_id,
            "total_count": 1200,
            "quantity": 1,
            "customer_notify": 1
        })
        return jsonify({
            "configured":True,
            "key_id":RAZORPAY_KEY_ID,
            "subscription_id":sub["id"],
            "plan":plan,
            "amount_inr":prices[plan]
        })
    except Exception as e:
        return jsonify({"error":"Razorpay subscription creation failed","detail":str(e)}),502

@app.post("/api/verify-subscription")
def verify_subscription():
    data=request.get_json(force=True)
    sid=data.get("razorpay_subscription_id","")
    pid=data.get("razorpay_payment_id","")
    sig=data.get("razorpay_signature","")
    if not sid or not pid or not sig or not RAZORPAY_KEY_SECRET:
        return jsonify({"verified":False}),400
    payload=f"{pid}|{sid}".encode()
    expected=hmac.new(RAZORPAY_KEY_SECRET.encode(),payload,hashlib.sha256).hexdigest()
    return jsonify({"verified":hmac.compare_digest(expected,sig)})

@app.post("/api/outfits")
def outfits():
    data=request.get_json(force=True)
    return jsonify(demo_outfits(data.get("items",[]),data.get("occasion","casual"),data.get("weather","warm"),data.get("style","smart casual")))

@app.post("/api/analyze")
def analyze():
    # Safe demo analyzer. Replace with a vision provider in production.
    name=(request.get_json(force=True).get("name") or "New clothing item").strip()
    return jsonify({"name":name, "category":classify(name), "message":"Item added. For automatic photo recognition, connect your preferred vision API in the server."})

if __name__=="__main__":
    app.run(host="0.0.0.0", port=int(os.getenv("PORT","5000")), debug=True)
