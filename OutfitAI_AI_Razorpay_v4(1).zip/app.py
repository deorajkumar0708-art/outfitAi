import os, itertools, json, hmac, hashlib, sqlite3, time, base64, mimetypes
from flask import Flask, render_template, request, jsonify
try:
    import razorpay
except ImportError:
    razorpay = None
try:
    from openai import OpenAI
except ImportError:
    OpenAI = None

app = Flask(__name__)
RAZORPAY_KEY_ID = os.getenv("RAZORPAY_KEY_ID", "")
RAZORPAY_KEY_SECRET = os.getenv("RAZORPAY_KEY_SECRET", "")
RAZORPAY_PLAN_IDS = {
    "weekly": os.getenv("RAZORPAY_PLAN_WEEKLY_ID", ""),
    "monthly": os.getenv("RAZORPAY_PLAN_MONTHLY_ID", ""),
    "yearly": os.getenv("RAZORPAY_PLAN_YEARLY_ID", ""),
}
rzp = razorpay.Client(auth=(RAZORPAY_KEY_ID, RAZORPAY_KEY_SECRET)) if razorpay and RAZORPAY_KEY_ID and RAZORPAY_KEY_SECRET else None
DB_PATH = os.getenv("OUTFITAI_DB", os.path.join(os.path.dirname(__file__), "outfitai.db"))
WEBHOOK_SECRET = os.getenv("RAZORPAY_WEBHOOK_SECRET", "")
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY", "")
OPENAI_MODEL = os.getenv("OPENAI_MODEL", "gpt-5.6-luna")
openai_client = OpenAI(api_key=OPENAI_API_KEY) if OpenAI and OPENAI_API_KEY else None


def db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def init_db():
    conn = db()
    conn.execute("""CREATE TABLE IF NOT EXISTS subscriptions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        subscription_id TEXT UNIQUE,
        plan TEXT,
        status TEXT,
        payment_id TEXT,
        created_at INTEGER,
        updated_at INTEGER
    )""")
    conn.commit(); conn.close()

init_db()

COLORS = ["black","white","blue","navy","grey","gray","beige","brown","green","red","pink","yellow","cream","denim"]
TOPS = ["t-shirt","shirt","top","polo","sweater","hoodie","kurta","blouse","jacket","coat"]
BOTTOMS = ["jeans","trousers","pants","shorts","skirt","chinos","pajama","joggers"]
SHOES = ["sneakers","shoes","boots","sandals","loafers","heels","flats"]

def classify(name):
    n = name.lower()
    if any(x in n for x in TOPS): return "top"
    if any(x in n for x in BOTTOMS): return "bottom"
    if any(x in n for x in SHOES): return "shoes"
    return "other"

def demo_outfits(items, occasion="casual", weather="warm", style="smart casual"):
    groups = {"top":[], "bottom":[], "shoes":[], "other":[]}
    for x in items:
        groups.setdefault(x.get("category") or classify(x.get("name","")), []).append(x)
    outfits=[]
    for t,b,s in itertools.product(groups["top"], groups["bottom"], groups["shoes"]):
        score=80
        if "formal" in occasion.lower() and any(k in t["name"].lower() for k in ["t-shirt","hoodie"]): score-=12
        if "rain" in weather.lower() and any(k in s["name"].lower() for k in ["sandals"]): score-=10
        if "smart" in style.lower() and any(k in s["name"].lower() for k in ["sneakers"]): score+=3
        outfits.append({"items":[t,b,s],"score":max(50,min(98,score)),"reason":f"Balanced for {occasion}, {weather} weather and {style} style."})
    return sorted(outfits,key=lambda x:-x["score"])[:8]


def extract_json(text):
    text = (text or "").strip()
    if text.startswith("```"):
        text = text.split("\n",1)[-1].rsplit("```",1)[0].strip()
    try: return json.loads(text)
    except Exception: pass
    start, end = text.find("{"), text.rfind("}")
    if start >= 0 and end > start:
        try: return json.loads(text[start:end+1])
        except Exception: pass
    return None

@app.route("/")
def home(): return render_template("index.html")

@app.get("/api/status")
def status():
    return jsonify({"ai_configured": bool(openai_client), "razorpay_configured": bool(rzp and all(RAZORPAY_PLAN_IDS.values()))})

@app.get("/api/plans")
def plans():
    return jsonify([
        {"id":"weekly","name":"Weekly","price_inr":29,"period":"week","description":"Try Pro with a low-risk weekly plan."},
        {"id":"monthly","name":"Monthly","price_inr":79,"period":"month","description":"Best balance for regular users.","badge":"POPULAR"},
        {"id":"yearly","name":"Yearly","price_inr":699,"period":"year","description":"Best value for long-term users.","badge":"BEST VALUE"}
    ])

@app.post("/api/create-subscription")
def create_subscription():
    data=request.get_json(force=True); plan=data.get("plan","monthly")
    prices={"weekly":29,"monthly":79,"yearly":699}
    if plan not in prices: return jsonify({"error":"Invalid plan"}),400
    plan_id=RAZORPAY_PLAN_IDS.get(plan,"")
    if not rzp or not plan_id:
        return jsonify({"configured":False,"plan":plan,"amount_inr":prices[plan],"message":"Razorpay is not configured yet."})
    try:
        sub=rzp.subscription.create({"plan_id":plan_id,"total_count":1200,"quantity":1,"customer_notify":1})
        return jsonify({"configured":True,"key_id":RAZORPAY_KEY_ID,"subscription_id":sub["id"],"plan":plan,"amount_inr":prices[plan]})
    except Exception as e:
        return jsonify({"error":"Razorpay subscription creation failed","detail":str(e)}),502

@app.post("/api/razorpay/webhook")
def razorpay_webhook():
    raw=request.get_data(); signature=request.headers.get("X-Razorpay-Signature","")
    if WEBHOOK_SECRET:
        expected=hmac.new(WEBHOOK_SECRET.encode(),raw,hashlib.sha256).hexdigest()
        if not hmac.compare_digest(expected,signature): return jsonify({"ok":False,"error":"invalid signature"}),401
    payload=request.get_json(silent=True) or {}; event=payload.get("event","")
    entity=((payload.get("payload") or {}).get("subscription") or {}).get("entity") or {}
    sid=entity.get("id"); plan_id=entity.get("plan_id",""); status=entity.get("status","")
    if sid:
        plan=next((k for k,v in RAZORPAY_PLAN_IDS.items() if v==plan_id),"unknown")
        payment=((payload.get("payload") or {}).get("payment") or {}).get("entity") or {}
        now=int(time.time()); conn=db()
        conn.execute("""INSERT INTO subscriptions(subscription_id,plan,status,payment_id,created_at,updated_at)
                        VALUES(?,?,?,?,?,?) ON CONFLICT(subscription_id) DO UPDATE SET
                        plan=excluded.plan,status=excluded.status,payment_id=excluded.payment_id,updated_at=excluded.updated_at""",
                     (sid,plan,status,payment.get("id",""),now,now))
        conn.commit(); conn.close()
    return jsonify({"ok":True,"event":event})

@app.post("/api/verify-subscription")
def verify_subscription():
    data=request.get_json(force=True); sid=data.get("razorpay_subscription_id",""); pid=data.get("razorpay_payment_id",""); sig=data.get("razorpay_signature","")
    if not sid or not pid or not sig or not RAZORPAY_KEY_SECRET: return jsonify({"verified":False}),400
    expected=hmac.new(RAZORPAY_KEY_SECRET.encode(),f"{pid}|{sid}".encode(),hashlib.sha256).hexdigest()
    return jsonify({"verified":hmac.compare_digest(expected,sig)})

@app.post("/api/outfits")
def outfits():
    data=request.get_json(force=True); items=data.get("items",[])
    if openai_client:
        prompt=f'''You are OutfitAI, a practical personal stylist. Use ONLY these closet items: {json.dumps(items, ensure_ascii=False)}.
Create up to 6 distinct complete outfits for occasion={data.get("occasion","casual")}, weather={data.get("weather","warm")}, style={data.get("style","smart casual")}.
Return ONLY valid JSON: {{"outfits":[{{"item_names":["exact item name"],"score":92,"reason":"short reason"}}]}}.
Never invent clothing items. Prefer culturally appropriate Indian combinations when useful, including kurta, saree, sherwani or Indo-western pieces if present.'''
        try:
            r=openai_client.responses.create(model=OPENAI_MODEL,input=prompt)
            parsed=extract_json(r.output_text)
            if parsed and isinstance(parsed.get("outfits"),list):
                by_name={x.get("name"):x for x in items}
                out=[]
                for o in parsed["outfits"][:6]:
                    chosen=[by_name[n] for n in o.get("item_names",[]) if n in by_name]
                    if chosen: out.append({"items":chosen,"score":max(1,min(100,int(o.get("score",85)))),"reason":o.get("reason","AI stylist recommendation.")})
                if out: return jsonify(out)
        except Exception as e:
            app.logger.warning("AI outfit generation failed: %s", e)
    return jsonify(demo_outfits(items,data.get("occasion","casual"),data.get("weather","warm"),data.get("style","smart casual")))

@app.post("/api/analyze")
def analyze():
    data=request.get_json(force=True) or {}; name=(data.get("name") or "New clothing item").strip(); image=data.get("image")
    if openai_client and image:
        try:
            if image.startswith("data:"):
                image_url=image
            else:
                image_url="data:image/jpeg;base64,"+image
            prompt='''Identify the single main clothing/fashion item in this image. Return ONLY JSON with keys: name, category, color, material, pattern, season, gender_style. category must be one of top,bottom,shoes,outerwear,dress,accessory,other. Use concise values. Do not identify the person.'''
            r=openai_client.responses.create(model=OPENAI_MODEL,input=[{"role":"user","content":[{"type":"input_text","text":prompt},{"type":"input_image","image_url":image_url}]}])
            parsed=extract_json(r.output_text)
            if parsed:
                parsed["category"]=parsed.get("category") or "other"
                parsed["emoji"]={"top":"👕","bottom":"👖","shoes":"👟","outerwear":"🧥","dress":"👗","accessory":"👜","other":"🧥"}.get(parsed["category"],"🧥")
                return jsonify(parsed)
        except Exception as e:
            app.logger.warning("AI image analysis failed: %s", e)
    return jsonify({"name":name,"category":classify(name),"color":"","message":"Item added using demo categorization. Set OPENAI_API_KEY for photo recognition."})

@app.post("/api/ai-style")
def ai_style():
    data=request.get_json(force=True) or {}
    if not openai_client: return jsonify({"configured":False,"message":"Set OPENAI_API_KEY to enable AI stylist chat."})
    prompt=f'''You are OutfitAI stylist. Closet: {json.dumps(data.get("items",[]),ensure_ascii=False)}. User request: {data.get("message","")}. Give a concise, useful styling answer using only closet items. Mention substitutions if an exact item is unavailable.''' 
    try:
        r=openai_client.responses.create(model=OPENAI_MODEL,input=prompt)
        return jsonify({"configured":True,"answer":r.output_text})
    except Exception as e:
        return jsonify({"configured":True,"error":"AI request failed","detail":str(e)}),502

if __name__=="__main__": app.run(host="0.0.0.0",port=int(os.getenv("PORT","5000")),debug=True)
