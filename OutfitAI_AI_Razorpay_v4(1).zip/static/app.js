const key="outfitai_items";
let items=JSON.parse(localStorage.getItem(key)||"[]");
const emojis={top:"👕",bottom:"👖",shoes:"👟",other:"🧥"};

function persist(){localStorage.setItem(key,JSON.stringify(items));renderCloset()}
function renderCloset(){
 const g=document.getElementById("closetGrid"), empty=document.getElementById("empty");
 empty.style.display=items.length?"none":"block";
 g.innerHTML=items.map((x,i)=>`<div class="item"><div class="emoji">${x.emoji||emojis[x.category]||"🧥"}</div><div><b>${escapeHtml(x.name)}</b><br><small>${x.category}</small></div><button onclick="removeItem(${i})" style="align-self:flex-end;background:#f2f1ed;padding:7px 10px">Remove</button></div>`).join("");
}
function addItem(){document.getElementById("modal").classList.remove("hidden");document.getElementById("itemName").focus()}
function closeModal(){document.getElementById("modal").classList.add("hidden")}
async function saveItem(){
 const name=document.getElementById("itemName").value.trim(); if(!name)return;
 const r=await fetch("/api/analyze",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({name})});
 const x=await r.json(); items.push({name:x.name,category:x.category,emoji:emojis[x.category]||"🧥"});persist();document.getElementById("itemName").value="";closeModal();showToast("Added to your closet")
}
async function analyzePhoto(event){
 const file=event.target.files?.[0]; if(!file)return;
 const status=document.getElementById("aiStatus"); status.textContent="Analyzing photo with AI…";
 const reader=new FileReader();
 reader.onload=async()=>{
   try{
    const r=await fetch("/api/analyze",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({image:reader.result})});
    const x=await r.json();
    items.push({name:x.name||"Clothing item",category:x.category||"other",emoji:x.emoji||emojis[x.category]||"🧥",color:x.color||"",material:x.material||"",pattern:x.pattern||""});
    persist(); status.textContent=`AI identified: ${x.name||"clothing item"}${x.color?" · "+x.color:""}`; showToast("📸 Added by AI");
   }catch(e){status.textContent="Photo analysis failed. Try again or add the item by name."}
 }; reader.readAsDataURL(file); event.target.value="";
}
async function askStylist(){
 const q=document.getElementById("styleQuestion").value.trim(); if(!q)return;
 const el=document.getElementById("stylistAnswer"); el.textContent="Stylist is thinking…";
 try{const r=await fetch("/api/ai-style",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({items,message:q})}); const x=await r.json(); el.textContent=x.answer||x.message||"Please try again."}catch(e){el.textContent="Could not reach the stylist."}
}
function removeItem(i){items.splice(i,1);persist()}
async function generate(){
 if(!items.some(x=>x.category==="top")||!items.some(x=>x.category==="bottom")||!items.some(x=>x.category==="shoes")){showToast("Add a top, bottom and shoes first.");return}
 const payload={items,occasion:document.getElementById("occasion").value,weather:document.getElementById("weather").value,style:document.getElementById("style").value};
 const r=await fetch("/api/outfits",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(payload)});
 const data=await r.json(); const el=document.getElementById("results");
 el.innerHTML=data.map((o,i)=>`<div class="result"><div class="score">${o.score}%</div><div class="pieces">${o.items.map(x=>x.emoji||"🧥").join(" ")}</div><b>${o.items.map(x=>escapeHtml(x.name)).join(" · ")}</b><p>${o.reason}</p><button class="save" onclick='saveOutfit(${JSON.stringify(o).replaceAll("'","&#39;")})'>♡ Save outfit</button></div>`).join("");
}
function saveOutfit(o){let saved=JSON.parse(localStorage.getItem("outfitai_saved")||"[]");saved.push(o);localStorage.setItem("outfitai_saved",JSON.stringify(saved));renderSaved();showToast("Outfit saved")}
function renderSaved(){let s=JSON.parse(localStorage.getItem("outfitai_saved")||"[]");document.getElementById("savedGrid").innerHTML=s.slice().reverse().map(o=>`<div class="saved-card"><div class="pieces">${o.items.map(x=>x.emoji||"🧥").join(" ")}</div><b>${o.items.map(x=>escapeHtml(x.name)).join(" · ")}</b><p>${o.score}% match</p></div>`).join("")||'<p style="color:#777">Your saved outfits will appear here.</p>'}
function showToast(t){let x=document.getElementById("toast");x.textContent=t;x.style.display="block";clearTimeout(window.tt);window.tt=setTimeout(()=>x.style.display="none",2200)}
function escapeHtml(s){return s.replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[m]))}
renderCloset();renderSaved();

let selectedPlan=null;
const planPrices={weekly:29,monthly:79,yearly:699};
function openPlans(){document.getElementById("pricing").scrollIntoView({behavior:"smooth"})}
function choosePlan(plan){
 selectedPlan=plan;
 const names={weekly:"Weekly Pro",monthly:"Monthly Pro",yearly:"Yearly Pro"};
 document.getElementById("selectedPlan").textContent=names[plan];
 document.getElementById("selectedPrice").textContent=`₹${planPrices[plan]} · ${plan==="weekly"?"7 days":plan==="monthly"?"30 days":"365 days"} access`;
 document.getElementById("planModal").classList.remove("hidden");
}
function closePlans(){document.getElementById("planModal").classList.add("hidden")}
async function startPayment(){
 const r=await fetch("/api/create-subscription",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({plan:selectedPlan})});
 const data=await r.json();
 if(!data.configured){showToast("Razorpay setup is not connected yet.");return}
 const options={
   key:data.key_id,
   subscription_id:data.subscription_id,
   name:"OutfitAI",
   description:`OutfitAI Pro — ${selectedPlan}`,
   theme:{color:"#111111"},
   handler:async function(response){
     const vr=await fetch("/api/verify-subscription",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(response)});
     const result=await vr.json();
     if(result.verified){
       localStorage.setItem("outfitai_pro","true");
       closePlans();
       showToast("🎉 Pro activated successfully!");
     }else showToast("Payment verification failed.");
   }
 };
 if(!window.Razorpay){showToast("Razorpay Checkout library is unavailable.");return}
 new Razorpay(options).open();
}
